import appStore from './appStore'
import stepFormStore from '../routes/Entry/FormDemo/store'

const store = {
  appStore,
  stepFormStore
}
export default store